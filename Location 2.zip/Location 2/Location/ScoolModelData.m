//
//  ScoolModelData.m
//
//  Created by macbook  on 7/6/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import "ScoolModelData.h"


NSString *const kScoolModelDataY = @"y";
NSString *const kScoolModelDataSid = @"sid";
NSString *const kScoolModelDataSName = @"sName";
NSString *const kScoolModelDataX = @"x";
NSString *const kScoolModelDataSShortName = @"sShortName";
NSString *const kScoolModelDataSSchoolAddress = @"sSchoolAddress";


@interface ScoolModelData ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation ScoolModelData

@synthesize y = _y;
@synthesize sid = _sid;
@synthesize sName = _sName;
@synthesize x = _x;
@synthesize sShortName = _sShortName;
@synthesize sSchoolAddress = _sSchoolAddress;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.y = [self objectOrNilForKey:kScoolModelDataY fromDictionary:dict];
            self.sid = [self objectOrNilForKey:kScoolModelDataSid fromDictionary:dict];
            self.sName = [self objectOrNilForKey:kScoolModelDataSName fromDictionary:dict];
            self.x = [self objectOrNilForKey:kScoolModelDataX fromDictionary:dict];
            self.sShortName = [self objectOrNilForKey:kScoolModelDataSShortName fromDictionary:dict];
            self.sSchoolAddress = [self objectOrNilForKey:kScoolModelDataSSchoolAddress fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.y forKey:kScoolModelDataY];
    [mutableDict setValue:self.sid forKey:kScoolModelDataSid];
    [mutableDict setValue:self.sName forKey:kScoolModelDataSName];
    [mutableDict setValue:self.x forKey:kScoolModelDataX];
    [mutableDict setValue:self.sShortName forKey:kScoolModelDataSShortName];
    [mutableDict setValue:self.sSchoolAddress forKey:kScoolModelDataSSchoolAddress];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.y = [aDecoder decodeObjectForKey:kScoolModelDataY];
    self.sid = [aDecoder decodeObjectForKey:kScoolModelDataSid];
    self.sName = [aDecoder decodeObjectForKey:kScoolModelDataSName];
    self.x = [aDecoder decodeObjectForKey:kScoolModelDataX];
    self.sShortName = [aDecoder decodeObjectForKey:kScoolModelDataSShortName];
    self.sSchoolAddress = [aDecoder decodeObjectForKey:kScoolModelDataSSchoolAddress];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_y forKey:kScoolModelDataY];
    [aCoder encodeObject:_sid forKey:kScoolModelDataSid];
    [aCoder encodeObject:_sName forKey:kScoolModelDataSName];
    [aCoder encodeObject:_x forKey:kScoolModelDataX];
    [aCoder encodeObject:_sShortName forKey:kScoolModelDataSShortName];
    [aCoder encodeObject:_sSchoolAddress forKey:kScoolModelDataSSchoolAddress];
}

- (id)copyWithZone:(NSZone *)zone
{
    ScoolModelData *copy = [[ScoolModelData alloc] init];
    
    if (copy) {

        copy.y = [self.y copyWithZone:zone];
        copy.sid = [self.sid copyWithZone:zone];
        copy.sName = [self.sName copyWithZone:zone];
        copy.x = [self.x copyWithZone:zone];
        copy.sShortName = [self.sShortName copyWithZone:zone];
        copy.sSchoolAddress = [self.sSchoolAddress copyWithZone:zone];
    }
    
    return copy;
}


@end
