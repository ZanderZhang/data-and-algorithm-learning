//
//  submitController.m
//  Location
//
//  Created by ZY on 7/6/15.
//  Copyright (c) 2015 mingThink. All rights reserved.
//

#import "submitController.h"
#import "AFNetworking.h"
#import "MBProgressHUD.h"
#import <MAMapKit/MAMapKit.h>

#define SUBMITURL @"http://api.zpx-app.com/action/gps.ashx?action=editScale"
@interface submitController ()<MAMapViewDelegate>
@property (weak, nonatomic) IBOutlet MAMapView *MAMapView;
@property (weak, nonatomic) IBOutlet UILabel *schoolName;
@property (weak, nonatomic) IBOutlet UILabel *schoolAddress;
@property (weak, nonatomic) IBOutlet UILabel *schoolLatitude;
@property (weak, nonatomic) IBOutlet UILabel *myLatitude;
@property (weak, nonatomic) IBOutlet UIButton *submitBtn;


@end

@implementation submitController

- (IBAction)submitBtnClick {
    [self sendRequest];
}
-(void)alert:(NSString *)message{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:0 message:message delegate:0 cancelButtonTitle:0 otherButtonTitles:@"确定", nil];
    [alert show];
}
-(void)sendRequest{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    manager.responseSerializer=[AFHTTPResponseSerializer serializer];
    
    [manager GET:[[NSString stringWithFormat:@"%@&sid=%@&x=%@&y=%@",SUBMITURL,_model.sid,_latitude,_longitude] stringByAddingPercentEscapesUsingEncoding:4] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        responseObject=[NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
                NSLog(@"%@\n%@",responseObject,[[NSString stringWithFormat:@"%@&sid=%@&x=%@&y=%@",SUBMITURL,_model.sid,_model.x,_model.y] stringByAddingPercentEscapesUsingEncoding:4]);
        if ([responseObject[@"status"]isEqualToString:@"true"]) {
            [self alert:@"提交成功"];
        }
        else{
            [self alert:@"提交失败"];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error=%@",error);
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil
                                                       message:[error localizedDescription]
                                                      delegate:nil
                                             cancelButtonTitle:@"确定"
                                             otherButtonTitles:nil];
        [alert show];
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.tableFooterView=[UIView new];
    _submitBtn.backgroundColor=[UIColor lightGrayColor];
    [self setInfo];
    [self setBack];

//    地图服务
    [self mapService];



}
#pragma mark -
#pragma mark - mapService
-(void)mapService
{   _MAMapView.delegate = self;
    _MAMapView.showsUserLocation = YES;
    [_MAMapView setUserTrackingMode: MAUserTrackingModeFollow animated:YES]; //地图跟着位置移动

}
-(void)mapView:(MAMapView *)mapView didUpdateUserLocation:(MAUserLocation *)userLocation
updatingLocation:(BOOL)updatingLocation
{
    if(updatingLocation)
    {
        //取出当前位置的坐标
        NSLog(@"高德地图latitude : %f,longitude: %f",userLocation.coordinate.latitude,userLocation.coordinate.longitude);
        
        _myLatitude.text=[NSString stringWithFormat:@"您当前坐标的经度:%f 纬度:%f",userLocation.coordinate.longitude,userLocation.coordinate.latitude];
    }
}
#pragma mark -
#pragma mark - setBack
-(void)setBack{
    UIButton *btn=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 30, 30)];
    [btn setBackgroundImage:[UIImage imageNamed:@"1_03(1)backBtn"] forState:0];
    [btn addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithCustomView:btn];
}
-(void)back{
    [self dismissViewControllerAnimated:1 completion:0];
}
#pragma mark -
#pragma mark - setInfo
-(void)setInfo{
    _schoolName.text=[NSString stringWithFormat:@"学校名:%@",_model.sName];
    _schoolAddress.text=[NSString stringWithFormat:@"学校地址:%@",_model.sSchoolAddress];
    _schoolLatitude.text=[NSString stringWithFormat:@"学校经度:%@ 纬度:%@",_model.y,_model.x];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
