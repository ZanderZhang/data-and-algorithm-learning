//
//  submitController.h
//  Location
//
//  Created by ZY on 7/6/15.
//  Copyright (c) 2015 mingThink. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ScoolModelData.h"
@interface submitController : UITableViewController
@property(nonatomic,strong)ScoolModelData*model;

@property(nonatomic,copy)NSString*latitude;
@property(nonatomic,copy)NSString*longitude;
@end
