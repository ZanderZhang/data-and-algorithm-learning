//
//  ScoolModelData.h
//
//  Created by macbook  on 7/6/15
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface ScoolModelData : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *y;
@property (nonatomic, strong) NSString *sid;
@property (nonatomic, strong) NSString *sName;
@property (nonatomic, strong) NSString *x;
@property (nonatomic, strong) NSString *sShortName;
@property (nonatomic, strong) NSString *sSchoolAddress;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
