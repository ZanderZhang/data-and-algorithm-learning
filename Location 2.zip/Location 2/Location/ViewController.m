//
//  ViewController.m
//  Location
//
//  Created by ZY on 7/6/15.
//  Copyright (c) 2015 mingThink. All rights reserved.
//

#import "ViewController.h"
#import "CCLocationManager.h"
#import "AFNetworking.h"
#import "MBProgressHUD.h"
#import "ScoolModelData.h"
#import "schoolNameCell.h"
#import "submitController.h"
@interface ViewController ()<CLLocationManagerDelegate>
@property (weak, nonatomic) IBOutlet UITextField *shoolName;
@property (weak, nonatomic) IBOutlet UIButton *searchBtn;

@end
#define SCHOOLLIST @"http://220.175.104.19:8721/action/gps.ashx?action=getSchoolInfoList"



#define IS_IOS7 ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7)
#define IS_IOS8 ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8)
@implementation ViewController{
    NSMutableArray *_dataArr;
    CLLocationManager *locationmanager;
    NSString *myLatitude;
    BOOL _state;
    NSString *longitude;
    NSString *latitude;
}
//输入学校名开始搜索
- (IBAction)searchClick {
    [self.view endEditing:1];
    [self sendRequest:[NSString stringWithFormat:@"&schoolName=%@",_shoolName.text]];
    _state=1;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    [self.view endEditing:1];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //    获取学校列表接口
    [self sendRequest:@""];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _searchBtn.backgroundColor=[UIColor lightGrayColor];
    _dataArr=[NSMutableArray new];
    self.tableView.tableFooterView=[UIView new];

//    获取我的坐标
    [self getMyLatitude];
}
#pragma mark -
#pragma mark - getMyLatitude
-(void)getMyLatitude{
    if (IS_IOS8) {
        [UIApplication sharedApplication].idleTimerDisabled = TRUE;
        locationmanager = [[CLLocationManager alloc] init];
        [locationmanager requestAlwaysAuthorization];        //NSLocationAlwaysUsageDescription
        [locationmanager requestWhenInUseAuthorization];     //NSLocationWhenInUseDescription
        locationmanager.delegate = self;
    }
//    __block __weak ViewController *wself = self;
    
    if (IS_IOS8) {
        
        [[CCLocationManager shareLocation] getLocationCoordinate:^(CLLocationCoordinate2D locationCorrrdinate) {
            
//            NSLog(@"%f %f",locationCorrrdinate.latitude,locationCorrrdinate.longitude);
           
            longitude=[NSString stringWithFormat:@"%f",locationCorrrdinate.longitude];
            latitude=[NSString stringWithFormat:@"%f",locationCorrrdinate.latitude];
            
        }];
    }
}
#pragma mark -
#pragma mark - parse
-(void)parseResponseObject:(id)responseObject{
    if (_state) {
        [_dataArr removeAllObjects];
    }
    for (NSDictionary *dic in responseObject[@"data"]) {
        ScoolModelData *model=[ScoolModelData modelObjectWithDictionary:dic];
        [_dataArr addObject:model];
    }
    [self.tableView reloadData];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataArr.count;
}
#pragma mark -
#pragma mark - didSelectRowAtIndexPath
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    submitController *submitVc=[[UIStoryboard storyboardWithName:@"submitController" bundle:0]instantiateInitialViewController];
    submitVc.model=_dataArr[indexPath.row];

    submitVc.longitude=longitude;
    submitVc.latitude=latitude;
    
    [self presentViewController:[[UINavigationController alloc] initWithRootViewController:submitVc] animated:1 completion:0];
}
#pragma mark -
#pragma mark - UITableViewCell
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    schoolNameCell *cell=[tableView dequeueReusableCellWithIdentifier:@"schoolNameCell" forIndexPath:indexPath];
    if (!cell) {
        cell=[[schoolNameCell alloc]initWithStyle:UITableViewCellStyleValue2 reuseIdentifier:@"schoolNameCell"];
    }
    ScoolModelData *model=_dataArr[indexPath.row];
    cell.schoolName.text=model.sName;
    cell.schoolAddress.text=model.sSchoolAddress;
    return cell;
}
-(void)sendRequest:(NSString *)appendStr{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    manager.responseSerializer=[AFHTTPResponseSerializer serializer];
    
    [manager GET:[[NSString stringWithFormat:@"%@%@",SCHOOLLIST,appendStr] stringByAddingPercentEscapesUsingEncoding:4] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        responseObject=[NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
//                NSLog(@"%@",responseObject);
        [self parseResponseObject:responseObject];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error=%@",error);
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil
                                                       message:[error localizedDescription]
                                                      delegate:nil
                                             cancelButtonTitle:@"确定"
                                             otherButtonTitles:nil];
        [alert show];
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
