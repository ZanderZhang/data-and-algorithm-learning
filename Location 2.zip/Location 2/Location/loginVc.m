//
//  loginVc.m
//  Location
//
//  Created by ZY on 7/10/15.
//  Copyright (c) 2015 mingThink. All rights reserved.
//

#import "loginVc.h"
#include "AFNetworking.h"
#include "MBProgressHUD.h"
#import "ViewController.h"
//#import "Canvas.h"
#define LOGINURL @"http://220.175.104.19:8721/action/gps.ashx?action=login&pwd="
@interface loginVc ()
//@property (weak, nonatomic) IBOutlet CSAnimationView *animationView;
@property (weak, nonatomic) IBOutlet UITextField *pwdTextField;

@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@end

@implementation loginVc
- (IBAction)loginClick {
    [self sendRequest];
}
-(void)alertLabel:(NSString *)message{
    UILabel *label=[[UILabel alloc]init];
    label.center=self.view.center;
    label.text=message;
    CGFloat width=[label.text boundingRectWithSize:CGSizeMake(40, CGFLOAT_MAX) options:NSStringDrawingTruncatesLastVisibleLine|NSStringDrawingUsesFontLeading|NSStringDrawingUsesDeviceMetrics attributes:0 context:0].size.width;
    label.bounds=CGRectMake(0, 0, width*2, 40);
    label.textColor=[UIColor whiteColor];
    label.backgroundColor=[UIColor blackColor];
    
    
    label.layer.cornerRadius = 20;
    label.layer.borderColor = [UIColor blackColor].CGColor;
    label.layer.borderWidth = 3;
    label.alpha=.5;
    label.clipsToBounds = 1;
    label.textAlignment=NSTextAlignmentCenter;
    [self.view addSubview:label];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [label removeFromSuperview];
    });
}
-(void)sendRequest{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    manager.responseSerializer=[AFHTTPResponseSerializer serializer];
//    _pwdTextField.text
    [manager GET:[[NSString stringWithFormat:@"%@%@",LOGINURL,@"1"] stringByAddingPercentEscapesUsingEncoding:4] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        responseObject=[NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
//                NSLog(@"%@%@",responseObject,[[NSString stringWithFormat:@"%@%@",LOGINURL,_pwdTextField.text] stringByAddingPercentEscapesUsingEncoding:4]);
        

        if ([responseObject[@"status"]isEqualToString:@"true"]) {
            ViewController *vc=[[UIStoryboard storyboardWithName:@"Main" bundle:0]instantiateInitialViewController];
            [self alertLabel:@"登录成功"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                 [self presentViewController:vc animated:1 completion:0];
            });
        }
        else
            [self alertLabel:@"登录失败"];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"error=%@",error);
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil
                                                       message:[error localizedDescription]
                                                      delegate:nil
                                             cancelButtonTitle:@"确定"
                                             otherButtonTitles:nil];
        [alert show];
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    _loginBtn.backgroundColor=[UIColor lightGrayColor];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
