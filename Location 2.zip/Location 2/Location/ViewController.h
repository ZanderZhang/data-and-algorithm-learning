//
//  ViewController.h
//  Location
//
//  Created by ZY on 7/6/15.
//  Copyright (c) 2015 mingThink. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UITableViewController


@end

