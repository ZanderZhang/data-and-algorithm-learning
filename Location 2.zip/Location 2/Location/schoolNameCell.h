//
//  schoolNameCell.h
//  Location
//
//  Created by ZY on 7/6/15.
//  Copyright (c) 2015 mingThink. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface schoolNameCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *schoolAddress;

@property (weak, nonatomic) IBOutlet UILabel *schoolName;
@end
