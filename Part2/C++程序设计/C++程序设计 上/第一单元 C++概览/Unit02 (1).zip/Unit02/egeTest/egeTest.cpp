#include "graphics.h"

int main(){
    initgraph(320, 240);
    
    outtextxy(20, 120, "Aloha World!");
    line(10, 10, 300, 200);
    circle(100, 100, 50);

    ege::getch();
    closegraph();
    
    return 0;
}
